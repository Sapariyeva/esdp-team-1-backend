export const SALT_WORK_FACTOR = 10;

