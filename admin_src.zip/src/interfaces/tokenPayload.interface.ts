export interface ITokenPayload {
  sub: string;
}