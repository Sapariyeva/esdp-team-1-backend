export enum EBarrierType {
    barrier = 'barrier',
    door = 'door'
}