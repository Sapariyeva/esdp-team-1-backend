export enum ERole {
    user = 'user',
    spaceAdmin = 'spaceAdmin',
    orgAdmin = 'orgAdmin',
    sa = 'sa'
}